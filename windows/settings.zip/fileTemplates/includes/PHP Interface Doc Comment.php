/**
 * @author Liangcheng Juves
 * Created at ${DATE} ${TIME}
 * Interface ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */

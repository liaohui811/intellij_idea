/**
 * @author Liangcheng Juves
 * Created at ${DATE} ${TIME}
 * Trait ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 */

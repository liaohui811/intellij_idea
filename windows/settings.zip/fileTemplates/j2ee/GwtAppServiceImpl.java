package ${PACKAGE_NAME};

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import ${QUALIFIED_SERVICE_NAME};

#parse("File Header.java")
public class ${NAME} 
        extends RemoteServiceServlet 
        implements ${SERVICE_NAME} {
}
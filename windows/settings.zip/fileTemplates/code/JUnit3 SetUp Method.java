public void setUp() 
        throws Exception {
  super.setUp();
  ${BODY}
}
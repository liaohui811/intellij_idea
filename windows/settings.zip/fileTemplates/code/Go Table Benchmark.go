#parse("File Header.java")
func Benchmark#[[$NAME$]]#(${PARAM_NAME} ${PARAM_TYPE}) {
	benchmarks := []struct {
		name string
	}{
		// TODO: benchmarks
	}
	for _, bm := range benchmarks {
		${PARAM_NAME}.Run(bm.name, func(${PARAM_NAME} ${PARAM_TYPE}) {
			for i := 0; i < ${PARAM_NAME}.N; i++ {
				#[[$END$]]#
			}
		})
	}
}

#parse("File Header.java")
func Benchmark#[[$NAME$]]#(${PARAM_NAME} ${PARAM_TYPE}) {
	for i := 0; i < ${PARAM_NAME}.N; i++ {
		#[[$END$]]#
	}
}

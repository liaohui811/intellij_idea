@org.junit.BeforeClass
public static void beforeClass() 
        throws Exception {
  ${BODY}
}
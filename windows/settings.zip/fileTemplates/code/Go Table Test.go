#parse("File Header.java")
func Test#[[$NAME$]]#(${PARAM_NAME} ${PARAM_TYPE}) {
	tests := []struct {
		name string
	}{
		// TODO: test cases
	}
	for _, test := range tests {
		${PARAM_NAME}.Run(test.name, func(${PARAM_NAME} ${PARAM_TYPE}) {
			#[[$END$]]#
		})
	}
}

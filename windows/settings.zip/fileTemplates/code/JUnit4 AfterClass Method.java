@org.junit.AfterClass
public static void afterClass() 
        throws Exception {
  ${BODY}
}
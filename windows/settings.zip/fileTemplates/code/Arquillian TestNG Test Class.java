import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.testng.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;

import static org.testng.Assert.*;

#parse("File Header.java")
public class ${NAME} extends Arquillian{
@Deployment
public static JavaArchive createDeployment(){
  return ShrinkWrap.create(JavaArchive.class)
  .addClass(${CLASS_NAME}.class)
  .addAsManifestResource(EmptyAsset.INSTANCE,"beans.xml");
  }
  ${BODY}
  }

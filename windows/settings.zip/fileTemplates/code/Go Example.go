#parse("File Header.java")
func Example#[[$NAME$]]#() {
	#[[$END$]]#
}

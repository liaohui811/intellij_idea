package main

#parse("File Header.java")
func main() {
	#[[$END$]]#
}

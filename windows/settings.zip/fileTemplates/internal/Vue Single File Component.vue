#parse("HTML File Header.html")
<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${COMPONENT_NAME}"
}
</script>

<style scoped>

</style>
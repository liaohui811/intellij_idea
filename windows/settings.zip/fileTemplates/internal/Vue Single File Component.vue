#parse("XML File Header.xml")
<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${COMPONENT_NAME}"
}
</script>

<style scoped>

</style>
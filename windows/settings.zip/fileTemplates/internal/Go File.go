package ${GO_PACKAGE_NAME}

#parse("File Header.java")

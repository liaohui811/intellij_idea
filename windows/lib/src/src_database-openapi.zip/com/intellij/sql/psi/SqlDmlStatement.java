package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlDmlStatement extends SqlStatement {
}

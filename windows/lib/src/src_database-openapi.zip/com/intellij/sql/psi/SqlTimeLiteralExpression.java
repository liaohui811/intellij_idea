package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlTimeLiteralExpression extends SqlLiteralExpression{
}

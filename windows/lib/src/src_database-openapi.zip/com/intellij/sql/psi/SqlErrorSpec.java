package com.intellij.sql.psi;

public interface SqlErrorSpec extends SqlElement {
}

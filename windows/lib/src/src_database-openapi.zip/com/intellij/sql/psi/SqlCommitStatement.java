package com.intellij.sql.psi;

public interface SqlCommitStatement extends SqlStatement {
}

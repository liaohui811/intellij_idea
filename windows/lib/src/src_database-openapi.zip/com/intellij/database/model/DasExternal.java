package com.intellij.database.model;

public interface DasExternal {
}

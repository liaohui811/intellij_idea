/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package icons;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class DatabaseIcons {
  private static @NotNull Icon load(@NotNull String path) {
    return IconManager.getInstance().getIcon(path, DatabaseIcons.class);
  }

  /** 16x16 */ public static final @NotNull Icon Access_method = load("/icons/access_method.svg");
  /** 16x16 */ public static final @NotNull Icon Adapter_script = load("/icons/adapter_script.svg");
  /** 10x10 */ public static final @NotNull Icon Add_hover = load("/icons/add-hover.svg");
  /** 10x10 */ public static final @NotNull Icon Add = load("/icons/add.svg");
  /** 16x16 */ public static final @NotNull Icon Aggregate = load("/icons/aggregate.svg");
  /** 16x16 */ public static final @NotNull Icon Argument = load("/icons/argument.svg");
  /** 16x16 */ public static final @NotNull Icon BlueKey = load("/icons/blueKey.svg");
  /** 16x16 */ public static final @NotNull Icon BlueKeyTrigger = load("/icons/blueKeyTrigger.svg");
  /** 16x16 */ public static final @NotNull Icon Body = load("/icons/body.svg");
  /** 16x16 */ public static final @NotNull Icon CheckConstraint = load("/icons/checkConstraint.svg");
  /** 16x16 */ public static final @NotNull Icon Col = load("/icons/col.svg");
  /** 16x16 */ public static final @NotNull Icon ColBlueKey = load("/icons/colBlueKey.svg");
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDot = load("/icons/colBlueKeyDot.svg");
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDotIndex = load("/icons/colBlueKeyDotIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyIndex = load("/icons/colBlueKeyIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColDot = load("/icons/colDot.svg");
  /** 16x16 */ public static final @NotNull Icon ColDotIndex = load("/icons/colDotIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKey = load("/icons/colGoldBlueKey.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDot = load("/icons/colGoldBlueKeyDot.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDotIndex = load("/icons/colGoldBlueKeyDotIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyIndex = load("/icons/colGoldBlueKeyIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldKey = load("/icons/colGoldKey.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDot = load("/icons/colGoldKeyDot.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDotIndex = load("/icons/colGoldKeyDotIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyIndex = load("/icons/colGoldKeyIndex.svg");
  /** 16x16 */ public static final @NotNull Icon ColGreyKey = load("/icons/colGreyKey.svg");
  /** 16x16 */ public static final @NotNull Icon ColIndex = load("/icons/colIndex.svg");
  /** 16x16 */ public static final @NotNull Icon Collation = load("/icons/collation.svg");
  /** 16x16 */ public static final @NotNull Icon CollectionType = load("/icons/collectionType.svg");
  /** 16x16 */ public static final @NotNull Icon Connector = load("/icons/connector.svg");
  /** 16x16 */ public static final @NotNull Icon ConsoleRun = load("/icons/consoleRun.svg");
  /** 16x16 */ public static final @NotNull Icon ConsoleShowPlan = load("/icons/consoleShowPlan.svg");
  /** 16x16 */ public static final @NotNull Icon Constant = load("/icons/constant.svg");
  /** 16x16 */ public static final @NotNull Icon Database = load("/icons/database.svg");
  /** 16x16 */ public static final @NotNull Icon DatabaseLink = load("/icons/databaseLink.svg");
  /** 16x16 */ public static final @NotNull Icon DataFile = load("/icons/dataFile.svg");
  /** 16x16 */ public static final @NotNull Icon Dbms = load("/icons/dbms.svg");
  /** 16x16 */ public static final @NotNull Icon DdlDbms = load("/icons/ddlDbms.svg");
  /** 16x16 */ public static final @NotNull Icon DefaultConstraint = load("/icons/defaultConstraint.svg");
  /** 16x16 */ public static final @NotNull Icon DriverBlue1 = load("/icons/driverBlue1.svg");
  /** 16x16 */ public static final @NotNull Icon DriverBlue2 = load("/icons/driverBlue2.svg");
  /** 16x16 */ public static final @NotNull Icon DriverBlue3 = load("/icons/driverBlue3.svg");
  /** 16x16 */ public static final @NotNull Icon DriverBlue4 = load("/icons/driverBlue4.svg");
  /** 16x16 */ public static final @NotNull Icon DriverGreen1 = load("/icons/driverGreen1.svg");
  /** 16x16 */ public static final @NotNull Icon DriverGreen2 = load("/icons/driverGreen2.svg");
  /** 16x16 */ public static final @NotNull Icon DriverGreen3 = load("/icons/driverGreen3.svg");
  /** 16x16 */ public static final @NotNull Icon DriverGreen4 = load("/icons/driverGreen4.svg");
  /** 16x16 */ public static final @NotNull Icon DriverPink1 = load("/icons/driverPink1.svg");
  /** 16x16 */ public static final @NotNull Icon DriverPink2 = load("/icons/driverPink2.svg");
  /** 16x16 */ public static final @NotNull Icon DriverPink3 = load("/icons/driverPink3.svg");
  /** 16x16 */ public static final @NotNull Icon DriverPink4 = load("/icons/driverPink4.svg");
  /** 16x16 */ public static final @NotNull Icon DriverRed1 = load("/icons/driverRed1.svg");
  /** 16x16 */ public static final @NotNull Icon DriverRed2 = load("/icons/driverRed2.svg");
  /** 16x16 */ public static final @NotNull Icon DriverRed3 = load("/icons/driverRed3.svg");
  /** 16x16 */ public static final @NotNull Icon DriverRed4 = load("/icons/driverRed4.svg");
  /** 16x16 */ public static final @NotNull Icon EditorOutput = load("/icons/editorOutput.svg");
  /** 16x16 */ public static final @NotNull Icon Extension = load("/icons/extension.svg");
  /** 16x16 */ public static final @NotNull Icon External_schema_object = load("/icons/external_schema_object.svg");
  /** 16x16 */ public static final @NotNull Icon FileFormat = load("/icons/fileFormat.svg");
  /** 16x16 */ public static final @NotNull Icon Foreign_datawrapper = load("/icons/foreign_datawrapper.svg");
  /** 16x16 */ public static final @NotNull Icon Foreign_server = load("/icons/foreign_server.svg");
  /** 16x16 */ public static final @NotNull Icon Foreign_table = load("/icons/foreign_table.svg");
  /** 16x16 */ public static final @NotNull Icon Function = load("/icons/function.svg");
  /** 16x16 */ public static final @NotNull Icon FunctionRun = load("/icons/functionRun.svg");
  /** 16x16 */ public static final @NotNull Icon GoldKey = load("/icons/goldKey.svg");
  /** 16x16 */ public static final @NotNull Icon GoldKeyAlt = load("/icons/goldKeyAlt.svg");
  /** 16x16 */ public static final @NotNull Icon GreenBugOverlap = load("/icons/greenBugOverlap.svg");
  /** 16x16 */ public static final @NotNull Icon HashCluster = load("/icons/hashCluster.svg");
  /** 16x16 */ public static final @NotNull Icon Index = load("/icons/index.svg");
  /** 16x16 */ public static final @NotNull Icon IndexCluster = load("/icons/indexCluster.svg");
  /** 16x16 */ public static final @NotNull Icon IndexFun = load("/icons/indexFun.svg");
  /** 16x16 */ public static final @NotNull Icon IndexUnique = load("/icons/indexUnique.svg");
  /** 16x16 */ public static final @NotNull Icon IndexUniqueFun = load("/icons/indexUniqueFun.svg");
  /** 16x16 */ public static final @NotNull Icon Macro = load("/icons/macro.svg");
  /** 16x16 */ public static final @NotNull Icon ManageDataSources = load("/icons/manageDataSources.svg");
  /** 16x16 */ public static final @NotNull Icon MaterializedLog = load("/icons/materializedLog.svg");
  /** 16x16 */ public static final @NotNull Icon MaterializedView = load("/icons/materializedView.svg");
  /** 16x16 */ public static final @NotNull Icon MongoField = load("/icons/mongoField.svg");
  /** 16x16 */ public static final @NotNull Icon MongoFieldGoldKey = load("/icons/mongoFieldGoldKey.svg");
  /** 16x16 */ public static final @NotNull Icon ObjectGroup = load("/icons/objectGroup.svg");
  /** 16x16 */ public static final @NotNull Icon Operator = load("/icons/operator.svg");
  /** 16x16 */ public static final @NotNull Icon Package = load("/icons/package.svg");
  /** 16x16 */ public static final @NotNull Icon Partition = load("/icons/partition.svg");
  /** 16x16 */ public static final @NotNull Icon Procedure = load("/icons/procedure.svg");
  /** 16x16 */ public static final @NotNull Icon ProcedureRun = load("/icons/procedureRun.svg");
  /** 16x16 */ public static final @NotNull Icon ProcGroup = load("/icons/procGroup.svg");
  /** 16x16 */ public static final @NotNull Icon Projection = load("/icons/projection.svg");
  /** 16x16 */ public static final @NotNull Icon Role = load("/icons/role.svg");
  /** 16x16 */ public static final @NotNull Icon Routine = load("/icons/routine.svg");
  /** 16x16 */ public static final @NotNull Icon Rule = load("/icons/rule.svg");
  /** 16x16 */ public static final @NotNull Icon RunDatabaseScript = load("/icons/runDatabaseScript.svg");
  /** 16x16 */ public static final @NotNull Icon ScheduledEvent = load("/icons/scheduledEvent.svg");
  /** 16x16 */ public static final @NotNull Icon Schema = load("/icons/schema.svg");
  /** 16x16 */ public static final @NotNull Icon Scripting_script = load("/icons/scripting_script.svg");
  /** 16x16 */ public static final @NotNull Icon Sequence = load("/icons/sequence.svg");
  /** 16x16 */ public static final @NotNull Icon Sql = load("/icons/sql.svg");
  /** 16x16 */ public static final @NotNull Icon SqlDmlStatement = load("/icons/sqlDmlStatement.svg");
  /** 16x16 */ public static final @NotNull Icon SqlGroupByType = load("/icons/sqlGroupByType.svg");
  /** 16x16 */ public static final @NotNull Icon SqlOtherStatement = load("/icons/sqlOtherStatement.svg");
  /** 16x16 */ public static final @NotNull Icon SqlSelectStatement = load("/icons/sqlSelectStatement.svg");
  /** 16x16 */ public static final @NotNull Icon SubmitDB = load("/icons/submitDB.svg");
  /** 16x16 */ public static final @NotNull Icon Synonym = load("/icons/synonym.svg");
  /** 16x16 */ public static final @NotNull Icon Table = load("/icons/table.svg");
  /** 16x16 */ public static final @NotNull Icon Tablespace = load("/icons/tablespace.svg");
  /** 13x13 */ public static final @NotNull Icon ToolWindowConsole = load("/icons/toolWindowConsole.svg");
  /** 13x13 */ public static final @NotNull Icon ToolWindowDatabase = load("/icons/toolWindowDatabase.svg");
  /** 13x13 */ public static final @NotNull Icon ToolwindowDatabaseChanges = load("/icons/toolwindowDatabaseChanges.svg");
  /** 13x13 */ public static final @NotNull Icon ToolWindowFiles = load("/icons/toolWindowFiles.svg");
  /** 13x13 */ public static final @NotNull Icon ToolWindowSQLGenerator = load("/icons/toolWindowSQLGenerator.svg");
  /** 16x16 */ public static final @NotNull Icon Trigger = load("/icons/trigger.svg");
  /** 16x16 */ public static final @NotNull Icon TSQLt = load("/icons/tSQLt.svg");
  /** 16x16 */ public static final @NotNull Icon Udf_script = load("/icons/udf_script.svg");
  /** 16x16 */ public static final @NotNull Icon UnspecifiedCluster = load("/icons/unspecifiedCluster.svg");
  /** 16x16 */ public static final @NotNull Icon User_mapping = load("/icons/user_mapping.svg");
  /** 16x16 */ public static final @NotNull Icon UserDriver = load("/icons/userDriver.svg");
  /** 16x16 */ public static final @NotNull Icon UtPLSQL = load("/icons/utPLSQL.svg");
  /** 16x16 */ public static final @NotNull Icon Warehouse = load("/icons/warehouse.svg");
}

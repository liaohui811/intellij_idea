package icons;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class CssIcons {
  private static @NotNull Icon load(@NotNull String path) {
    return IconManager.getInstance().getIcon(path, CssIcons.class);
  }

  /** 16x16 */ public static final @NotNull Icon Custom_property = load("/icons/css/custom_property.svg");
  /** 16x16 */ public static final @NotNull Icon Property = load("/icons/css/property.svg");
  /** 16x16 */ public static final @NotNull Icon Pseudo_class = load("/icons/css/pseudo-class.svg");
  /** 16x16 */ public static final @NotNull Icon Pseudo_element = load("/icons/css/pseudo-element.svg");
  /** 13x13 */ public static final @NotNull Icon Toolwindow = load("/icons/css/toolwindow.svg");
}

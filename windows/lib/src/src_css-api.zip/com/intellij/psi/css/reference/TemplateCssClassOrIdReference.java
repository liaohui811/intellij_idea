package com.intellij.psi.css.reference;

public interface TemplateCssClassOrIdReference extends CssReference {
}

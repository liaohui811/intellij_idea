package com.intellij.psi.css.inspections.clones;

import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;

public interface CssDuplicatesService {
  static CssDuplicatesService getInstance() {
    return ServiceManager.getService(CssDuplicatesService.class);
  }

  boolean skipDuplicatesAnalysis(@NotNull VirtualFile file);
}

package com.intellij.psi.css;

public interface CssApplyRule extends CssAtRule, CssOneLineStatement {
}

package com.intellij.psi.css.descriptor;

public interface CssPseudoElementDescriptor extends CssPseudoSelectorDescriptor {
}

/*
 * Copyright 2000-2019 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.toolWindow;

import com.intellij.openapi.extensions.AbstractExtensionPointBean;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.project.Project;
import com.intellij.util.xmlb.annotations.Attribute;
import org.jetbrains.annotations.Nls;

/**
 * Provides content tab for Spring toolwindow.
 *
 * @author Yann C&eacute;bron
 */
public abstract class SpringToolWindowContent extends AbstractExtensionPointBean {

  public static final String TOOLWINDOW_ID = "Spring";

  public static final ExtensionPointName<SpringToolWindowContent> EP_NAME =
    ExtensionPointName.create("com.intellij.spring.toolWindowContent");

  @Attribute("displayName")
  @Nls(capitalization = Nls.Capitalization.Title)
  public String displayName;

  @Attribute("icon")
  public String icon;

  public abstract boolean isAvailable(Project project);

  public abstract SpringBaseView createSpringView(Project project);
}

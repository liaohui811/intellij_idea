/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.profiles;

import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

public abstract class SpringProfilesFactory {
  public static SpringProfilesFactory getInstance() {
    return ServiceManager.getService(SpringProfilesFactory.class);
  }

  @NotNull
  public abstract List<SpringProfileTarget> findProfileTargets(@NotNull Module module, boolean includeTests);

  @Nullable
  public abstract SpringProfileTarget findProfileTarget(@NotNull Module module, boolean includeTests, @NotNull String profileName);

  public abstract PsiReference @NotNull [] getProfilesReferences(@NotNull Module module, @NotNull PsiElement element,
                                                                 @Nullable String value, int valueOffset,
                                                                 @NotNull String delimiters, boolean isDefinition);

  /**
   * @return parsed profiles expressions that can be matched against active profiles
   * @throws SpringProfilesFactory.MalformedProfileExpressionException if profile expression is malformed
   */
  public abstract Predicate<Set<String>> parseProfileExpressions(@NotNull Collection<String> expressions);

  public static class MalformedProfileExpressionException extends RuntimeException {
    MalformedProfileExpressionException(String message) {
      super(message);
    }
  }
}

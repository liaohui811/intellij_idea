// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam;

import com.intellij.codeInsight.MetaAnnotationUtil;
import com.intellij.jam.JamElement;
import com.intellij.jam.JamService;
import com.intellij.jam.JamStringAttributeElement;
import com.intellij.jam.annotations.JamPsiConnector;
import com.intellij.jam.annotations.JamPsiValidity;
import com.intellij.jam.model.common.CommonModelElement;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiMember;
import com.intellij.psi.PsiType;
import com.intellij.semantic.SemKey;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.DefaultSpringBeanQualifier;
import com.intellij.spring.model.SpringProfile;
import com.intellij.spring.model.SpringQualifier;
import com.intellij.spring.model.jam.profile.SpringContextProfile;
import com.intellij.spring.model.jam.qualifiers.SpringJamQualifier;
import com.intellij.util.ArrayUtilRt;
import com.intellij.util.SmartList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public abstract class JamPsiMemberSpringBean<T extends PsiMember> extends CommonModelElement.PsiBase
  implements JamElement, CommonSpringBean {

  public static final SemKey<JamPsiMemberSpringBean> PSI_MEMBER_SPRING_BEAN_JAM_KEY =
    JamService.JAM_ALIASING_ELEMENT_KEY.subKey("PsiMemberSpringBean");

  @Override
  @NotNull
  @JamPsiConnector
  public abstract T getPsiElement();

  @Override
  @JamPsiValidity
  public abstract boolean isValid();

  @Override
  @Nullable
  public PsiType getBeanType(final boolean considerFactories) {
    return getBeanType();
  }

  @Override
  public String @NotNull [] getAliases() {
    return ArrayUtilRt.EMPTY_STRING_ARRAY;
  }

  protected List<String> getStringNames(List<JamStringAttributeElement<String>> elements) {
    List<String> aliases = new SmartList<>();
    for (JamStringAttributeElement<String> element : elements) {
      String aliasName = element.getStringValue();
      if (!StringUtil.isEmptyOrSpaces(aliasName)) {
        aliases.add(aliasName);
      }
    }
    return aliases;
  }

  @Override
  @NotNull
  public Collection<SpringQualifier> getSpringQualifiers() {
    Collection<SpringQualifier> jamQualifiers = getQualifiers();
    return jamQualifiers.isEmpty() ? Collections.singleton(DefaultSpringBeanQualifier.create(this)) : jamQualifiers;
  }

  @NotNull
  public Collection<SpringQualifier> getQualifiers() {
    final Module module = getModule();
    if (module == null) {
      return Collections.emptySet();
    }

    return SpringJamQualifier.findSpringJamQualifiers(module, getPsiElement());
  }

  @Override
  public boolean isPrimary() {
    return MetaAnnotationUtil.isMetaAnnotated(getPsiElement(), Collections.singleton(SpringAnnotationsConstants.PRIMARY));
  }

  @NotNull
  @Override
  public SpringProfile getProfile() {
    PsiMember psiElement = getPsiElement();
    SpringContextProfile springProfile = getProfile(psiElement);
    if (springProfile == null) {
      springProfile = getProfile(psiElement.getContainingClass());
    }
    return springProfile != null ? springProfile : SpringProfile.DEFAULT;
  }

  @Nullable
  public SpringContextProfile getProfile(@Nullable PsiMember psiElement) {
    return psiElement == null ? null : JamService.getJamService(getPsiManager().getProject())
      .getJamElement(SpringContextProfile.CONTEXT_PROFILE_JAM_KEY, psiElement);
  }
}

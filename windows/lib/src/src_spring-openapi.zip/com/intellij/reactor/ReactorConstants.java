/*
 * Copyright 2000-2017 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.reactor;

import org.jetbrains.annotations.NonNls;

/**
 * Constants from Reactor framework.
 */
@NonNls
public final class ReactorConstants {

  public static final String FLUX = "reactor.core.publisher.Flux";
  public static final String MONO = "reactor.core.publisher.Mono";

  public static final String SUBSCRIBER = "org.reactivestreams.Subscriber";
  public static final String PUBLISHER = "org.reactivestreams.Publisher";
  public static final String PROCESSOR = "org.reactivestreams.Processor";
  public static final String SUBSCRIPTION = "org.reactivestreams.Subscription";

  public static final String HOOKS = "reactor.core.publisher.Hooks";
  public static final String REACTOR_DEBUG_AGENT = "reactor.tools.agent.ReactorDebugAgent";
}

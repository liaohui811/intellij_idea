// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package icons;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class SpringApiIcons {
  private static @NotNull Icon load(@NotNull String path) {
    return IconManager.getInstance().getIcon(path, SpringApiIcons.class);
  }

  /** 16x16 */ public static final @NotNull Icon AbtractBean = load("/icons/abtractBean.svg");
  /** 16x16 */ public static final @NotNull Icon FactoryMethodBean = load("/icons/factoryMethodBean.svg");
  /** 16x16 */ public static final @NotNull Icon FileSet = load("/icons/fileSet.svg");

  public final static class Gutter {
    /** 12x12 */ public static final @NotNull Icon FactoryMethodBean = load("/icons/gutter/factoryMethodBean.svg");
    /** 12x12 */ public static final @NotNull Icon InfrastructureBean = load("/icons/gutter/infrastructureBean.svg");
    /** 12x12 */ public static final @NotNull Icon Listener = load("/icons/gutter/listener.svg");
    /** 12x12 */ public static final @NotNull Icon ParentBeanGutter = load("/icons/gutter/parentBeanGutter.svg");
    /** 12x12 */ public static final @NotNull Icon Publisher = load("/icons/gutter/publisher.svg");
    /** 12x12 */ public static final @NotNull Icon RequestMapping = load("/icons/gutter/requestMapping.svg");
    /** 12x12 */ public static final @NotNull Icon ShowAutowiredCandidates = load("/icons/gutter/showAutowiredCandidates.svg");
    /** 12x12 */ public static final @NotNull Icon ShowAutowiredDependencies = load("/icons/gutter/showAutowiredDependencies.svg");
    /** 12x12 */ public static final @NotNull Icon ShowCacheable = load("/icons/gutter/showCacheable.svg");
    /** 12x12 */ public static final @NotNull Icon Spring = load("/icons/gutter/spring.svg");
    /** 12x12 */ public static final @NotNull Icon SpringBean = load("/icons/gutter/springBean.svg");
    /** 12x12 */ public static final @NotNull Icon SpringBeanMethod = load("/icons/gutter/springBeanMethod.svg");
    /** 12x12 */ public static final @NotNull Icon SpringConfig = load("/icons/gutter/springConfig.svg");
    /** 12x12 */ public static final @NotNull Icon SpringJavaBean = load("/icons/gutter/springJavaBean.svg");
    /** 12x12 */ public static final @NotNull Icon SpringProperty = load("/icons/gutter/springProperty.svg");
    /** 12x12 */ public static final @NotNull Icon SpringScan = load("/icons/gutter/springScan.svg");

  }
  /** 16x16 */ public static final @NotNull Icon ImplicitBean = load("/icons/implicitBean.svg");
  /** 16x16 */ public static final @NotNull Icon InfrastructureBean = load("/icons/infrastructureBean.svg");
  /** 16x16 */ public static final @NotNull Icon Listener = load("/icons/listener.svg");
  /** 16x16 */ public static final @NotNull Icon PrototypeBean = load("/icons/prototypeBean.svg");
  /** 16x16 */ public static final @NotNull Icon RequestMapping = load("/icons/RequestMapping.svg");
  /** 16x16 */ public static final @NotNull Icon ShowAutowiredDependencies = load("/icons/showAutowiredDependencies.svg");
  /** 16x16 */ public static final @NotNull Icon ShowCacheable = load("/icons/showCacheable.svg");
  /** 16x16 */ public static final @NotNull Icon Spring = load("/icons/spring.svg");
  /** 16x16 */ public static final @NotNull Icon SpringBean = load("/icons/springBean.svg");
  /** 16x16 */ public static final @NotNull Icon SpringConfig = load("/icons/springConfig.svg");
  /** 16x16 */ public static final @NotNull Icon SpringJavaBean = load("/icons/springJavaBean.svg");
  /** 16x16 */ public static final @NotNull Icon SpringJavaConfig = load("/icons/springJavaConfig.svg");
  /** 16x16 */ public static final @NotNull Icon SpringProfile = load("/icons/SpringProfile.svg");
  /** 16x16 */ public static final @NotNull Icon SpringProperty = load("/icons/springProperty.svg");
  /** 13x13 */ public static final @NotNull Icon SpringToolWindow = load("/icons/springToolWindow.svg");
  /** 16x16 */ public static final @NotNull Icon SpringWeb = load("/icons/SpringWeb.svg");
}

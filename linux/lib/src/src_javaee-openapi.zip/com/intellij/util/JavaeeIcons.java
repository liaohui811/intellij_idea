/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.util;

import com.intellij.icons.AllIcons;
import icons.JavaUltimateIcons;
import org.jetbrains.annotations.ApiStatus;

import javax.swing.*;

/**
 * @author peter
 */
public class JavaeeIcons implements PlatformIcons {
  public static final Icon WEB_FOLDER_CLOSED = AllIcons.Nodes.WebFolder;

  public static final Icon EJB_CLASS_ICON = JavaUltimateIcons.Javaee.EjbClass;
  public static final Icon EJB_INTERCEPTOR_CLASS_ICON = JavaUltimateIcons.Javaee.InterceptorClass;
  public static final Icon EJB_HOME_INTERFACE_ICON = AllIcons.Javaee.Home;
  public static final Icon EJB_LOCAL_HOME_INTERFACE_ICON = AllIcons.Javaee.Home;
  public static final Icon EJB_LOCAL_INTERFACE_ICON = AllIcons.Nodes.Interface;
  public static final Icon EJB_REMOTE_INTERFACE_ICON = JavaUltimateIcons.Javaee.Remote;
  public static final Icon EJB_CREATE_METHOD_ICON = JavaUltimateIcons.Javaee.EjbCreateMethod;
  public static final Icon EJB_FINDER_METHOD_ICON = JavaUltimateIcons.Javaee.EjbFinderMethod;
  public static final Icon EJB_BUSINESS_METHOD_ICON = JavaUltimateIcons.Javaee.EjbBusinessMethod;
  public static final Icon EJB_CMP_FIELD_ICON = JavaUltimateIcons.Javaee.EjbCmpField;
  public static final Icon EJB_CMR_FIELD_ICON = JavaUltimateIcons.Javaee.EjbCmrField;
  public static final Icon EJB_PRIMARY_KEY_CLASS = JavaUltimateIcons.Javaee.EjbPrimaryKeyClass;
  public static final Icon EJB_REFERENCE = JavaUltimateIcons.Javaee.EjbReference;
  public static final Icon EJB_FIELD_PK = AllIcons.Nodes.FieldPK;

  public static final Icon SESSION_BEAN = JavaUltimateIcons.Javaee.SessionBean;
  public static final Icon ENTITY_BEAN = JavaUltimateIcons.Javaee.EntityBean;
  public static final Icon MESSAGE_BEAN = JavaUltimateIcons.Javaee.MessageBean;
  public static final Icon EJB_INTERCEPTOR_METHOD_ICON = JavaUltimateIcons.Javaee.InterceptorMethod;
  public static final Icon JPA_ICON = JavaUltimateIcons.Javaee.JpaFacet;
  public static final Icon RELATIONSHIP_ICON = JavaUltimateIcons.Javaee.PersistenceRelationship;
  public static final Icon ID_RELATIONSHIP_ICON = JavaUltimateIcons.Javaee.PersistenceIdRelationship;
  public static final Icon ATTRIBUTE_ICON = JavaUltimateIcons.Javaee.PersistenceAttribute;
  public static final Icon ID_ATTRIBUTE_ICON = JavaUltimateIcons.Javaee.PersistenceId;
  public static final Icon ENTITY_ICON = AllIcons.Javaee.PersistenceEntity;
  public static final Icon MAPPED_SUPERCLASS_ICON = JavaUltimateIcons.Javaee.PersistenceMappedSuperclass;
  public static final Icon EMBEDDABLE_ICON = JavaUltimateIcons.Javaee.PersistenceEmbeddable;
  public static final Icon ENTITY_LISTENER_ICON = JavaUltimateIcons.Cdi.Listener;
  public static final Icon PERSISTENCE_UNIT_ICON = JavaUltimateIcons.Javaee.PersistenceUnit;
  public static final Icon EJB_JAR = JavaUltimateIcons.Javaee.Ejb_jar_xml;
  public static final Icon EJB_MODULE_SMALL = JavaUltimateIcons.Javaee.EjbModule;
  public static final Icon APPLICATION_XML = JavaUltimateIcons.Javaee.Application_xml;
  public static final Icon APP_MODULE_SMALL = JavaUltimateIcons.Javaee.JavaeeAppModule;
  public static final Icon WEB_XML = JavaUltimateIcons.Javaee.Web_xml;
  public static final Icon WEB_MODULE_SMALL = JavaUltimateIcons.Web.WebModule;
  public static final Icon EJBQL_METHOD_GUTTER_ICON = AllIcons.Gutter.ImplementedMethod;
  public static final Icon DATASOURCE_REMOTE_INSTANCE = AllIcons.ToolbarDecorator.AddRemoteDatasource;
}

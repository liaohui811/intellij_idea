package com.intellij.javaee.context;

import com.intellij.facet.FacetTypeId;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.facet.JavaeeFacet;
import org.jetbrains.annotations.NotNull;

public interface FacetContextProvider {

  FacetTypeId<? extends JavaeeFacet> getFacetId();

  String getDeploymentContext(@NotNull WebModuleContextProvider webModuleContextProvider,
                              @NotNull DeploymentModel deploymentModel,
                              @NotNull JavaeeFacet facet);
}

// Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model.autoconfigure;

public final class SpringBootAutoconfigureClassesConstants {

  public static final String ENABLE_AUTO_CONFIGURATION =
    "org.springframework.boot.autoconfigure.EnableAutoConfiguration";

  public static final String SPRING_BOOT_APPLICATION =
    "org.springframework.boot.autoconfigure.SpringBootApplication";

  public static final String AUTO_CONFIGURE_ORDER =
    "org.springframework.boot.autoconfigure.AutoConfigureOrder";

  public static final String AUTO_CONFIGURE_AFTER =
    "org.springframework.boot.autoconfigure.AutoConfigureAfter";

  public static final String AUTO_CONFIGURE_BEFORE =
    "org.springframework.boot.autoconfigure.AutoConfigureBefore";


  public static final String CONDITIONAL_ON_CLASS =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnClass";

  public static final String CONDITIONAL_ON_MISSING_CLASS =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass";

  public static final String CONDITIONAL_ON_BEAN =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnBean";
  public static final String CONDITIONAL_ON_MISSING_BEAN =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean";

  public static final String CONDITIONAL_ON_EXPRESSION =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnExpression";

  public static final String CONDITIONAL_ON_SINGLE_CANDIDATE =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate";

  public static final String CONDITIONAL_ON_RESOURCE =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnResource";

  public static final String CONDITIONAL_ON_WEB_APPLICATION =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication";
  public static final String CONDITIONAL_ON_NOT_WEB_APPLICATION =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication";

  public static final String CONDITIONAL_ON_PROPERTY =
    "org.springframework.boot.autoconfigure.condition.ConditionalOnProperty";

  public static final String CONDITIONAL_ON_INITIALIZED_RESTARTER =
    "org.springframework.boot.devtools.restart.ConditionalOnInitializedRestarter";

  public static final String CONDITIONAL_ON_ENABLED_RESOURCE_CHAIN =
    "org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain";

  public static final String CONDITIONAL_ON_REPOSITORY_TYPE =
    "org.springframework.boot.autoconfigure.data.ConditionalOnRepositoryType";


  public static final String CONDITIONAL_ON_ENABLED_HEALTH_INDICATOR =
    "org.springframework.boot.actuate.autoconfigure.ConditionalOnEnabledHealthIndicator";
  public static final String CONDITIONAL_ON_ENABLED_HEALTH_INDICATOR_SB2 =
    "org.springframework.boot.actuate.autoconfigure.health.ConditionalOnEnabledHealthIndicator";

  public static final String CONDITIONAL_ON_ENABLED_INFO_CONTRIBUTOR =
    "org.springframework.boot.actuate.autoconfigure.ConditionalOnEnabledInfoContributor";
  public static final String CONDITIONAL_ON_ENABLED_INFO_CONTRIBUTOR_SB2 =
    "org.springframework.boot.actuate.autoconfigure.info.ConditionalOnEnabledInfoContributor";

  public static final String CONDITIONAL_ON_MANAGEMENT_PORT =
    "org.springframework.boot.actuate.autoconfigure.web.server.ConditionalOnManagementPort";
}
